package paquete01;

import java.util.List;

public class Controlador {

    private Modelo modelo;
    private Vista vista;

    public Controlador(Modelo modelo, Vista vista) {
        this.modelo = modelo;
        this.vista = vista;
    }

    public void iniciar() {
        vista.mostrarMenu();
        int opcion = vista.leerOpcion();
        while (opcion != 0) {
            switch (opcion) {
                case 1:
                    agregarCliente();
                    break;
                case 2:
                    actualizarCliente();
                    break;
                case 3:
                    eliminarCliente();
                    break;
                case 4:
                    mostrarClientes();
                    break;
                case 5:
                    agregarPlan();
                    break;
                case 6:
                    actualizarPlan();
                    break;
                case 7:
                    eliminarPlan();
                    break;
                case 8:
                    mostrarPlanes();
                    break;
                default:
                    System.out.println("Opción inválida.");
                    break;
            }
            vista.mostrarMenu();
            opcion = vista.leerOpcion();
        }
    }

    public void agregarCliente() {
        Cliente cliente = vista.solicitarDatosCliente();
        modelo.agregarCliente(cliente);
    }

    public void actualizarCliente() {
        int clienteId = vista.solicitarIdCliente();
        Cliente cliente = modelo.obtenerClientePorId(clienteId);
        if (cliente != null) {
            Cliente nuevosDatos = vista.solicitarDatosCliente();
            nuevosDatos.setId(clienteId);
            modelo.actualizarCliente(nuevosDatos);
        } else {
            System.out.println("Cliente no encontrado.");
        }
    }

    public void eliminarCliente() {
        int clienteId = vista.solicitarIdCliente();
        Cliente cliente = modelo.obtenerClientePorId(clienteId);
        if (cliente != null) {
            modelo.eliminarCliente(clienteId);
        } else {
            System.out.println("Cliente no encontrado.");
        }
    }

    public void mostrarClientes() {
        List<Cliente> clientes = modelo.obtenerTodosLosClientes();
        vista.mostrarClientes(clientes);
    }

    public void agregarPlan() {
        int opcionTipoPlan = vista.solicitarTipoPlan();
        Plan plan;
        switch (opcionTipoPlan) {
            case 1:
                plan = vista.solicitarDatosPlanPostPagoMinutosMegasEconomico();
                break;
            case 2:
                plan = vista.solicitarDatosPlanPostPagoMinutos();
                break;
            case 3:
                plan = vista.solicitarDatosPlanPostPagoMegas();
                break;
            case 4:
                plan = vista.solicitarDatosPlanPostPagoMinutosMegas();
                break;
            default:
                System.out.println("Opción inválida.");
                return;
        }
        modelo.agregarPlan(plan);
    }

    public void actualizarPlan() {
        int planId = vista.solicitarIdPlan();
        Plan plan = modelo.obtenerPlanPorId(planId);
        if (plan != null) {
            Plan nuevosDatos = vista.solicitarDatosPlan(plan.getTipoPlan()); // Pasamos el tipo de plan aquí
            nuevosDatos.setId(planId);
            modelo.actualizarPlan(nuevosDatos);
        } else {
            System.out.println("Plan no encontrado.");
        }
    }

    public void eliminarPlan() {
        int planId = vista.solicitarIdPlan();
        Plan plan = modelo.obtenerPlanPorId(planId);
        if (plan != null) {
            modelo.eliminarPlan(planId);
        } else {
            System.out.println("Plan no encontrado.");
        }
    }

    public void mostrarPlanes() {
        List<Plan> planes = modelo.obtenerTodosLosPlanes();
        vista.mostrarListaPlanes(planes);
    }
}





package paquete01;

import java.util.Scanner;

public class EjecutarMovUTPL {

    public static void main(String[] args) {
        System.out.println("Proyecto 2B");
        
        Modelo modelo = new Modelo();
        Vista vista = new Vista();
        Controlador controlador = new Controlador(modelo, vista);
        
        Scanner scanner = new Scanner(System.in);
        int opcion;
        
        do {
            opcion = vista.mostrarMenu();
            
            switch (opcion) {
                case 1:
                    controlador.agregarCliente();
                    break;
                case 2:
                    controlador.agregarPlan();
                    break;
                case 3:
                    controlador.actualizarCliente();
                    break;
                case 4:
                    controlador.actualizarPlan();
                    break;
                case 5:
                    controlador.eliminarCliente();
                    break;
                case 6:
                    controlador.eliminarPlan();
                    break;
                case 7:
                    controlador.mostrarClientes();
                    break;
                case 8:
                    controlador.mostrarPlanes();
                    break;
                case 0:
                    System.out.println("Saliendo del programa...");
                    break;
                default:
                    System.out.println("Opción inválida, intente de nuevo.");
                    break;
            }
        } while (opcion != 0);

        scanner.close();
    }
}

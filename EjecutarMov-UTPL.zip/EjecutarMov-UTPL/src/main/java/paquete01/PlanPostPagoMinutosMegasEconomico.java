package paquete01;

public class PlanPostPagoMinutosMegasEconomico extends Plan{
    private int minutos;
    private double costoMinutos;
    private int megasEnGigas;
    private double costoPorGigas;
    private double porcentajeDescuento;

    // Constructor
    public PlanPostPagoMinutosMegasEconomico() {
        super("PlanPostPagoMinutosMegasEconomico");
    }

    public int getMinutos() {
        return minutos;
    }

    public void setMinutos(int minutos) {
        this.minutos = minutos;
    }

    public double getCostoMinutos() {
        return costoMinutos;
    }

    public void setCostoMinutos(double costoMinutos) {
        this.costoMinutos = costoMinutos;
    }

    public int getMegasEnGigas() {
        return megasEnGigas;
    }

    public void setMegasEnGigas(int megasEnGigas) {
        this.megasEnGigas = megasEnGigas;
    }

    public double getCostoPorGigas() {
        return costoPorGigas;
    }

    public void setCostoPorGigas(double costoPorGigas) {
        this.costoPorGigas = costoPorGigas;
    }

    public double getPorcentajeDescuento() {
        return porcentajeDescuento;
    }

    public void setPorcentajeDescuento(double porcentajeDescuento) {
        this.porcentajeDescuento = porcentajeDescuento;
    }
    
}

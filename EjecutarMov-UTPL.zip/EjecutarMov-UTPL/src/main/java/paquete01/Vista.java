package paquete01;

import java.util.Scanner;
import java.util.List;

public class Vista {

    private Scanner scanner;

    public Vista() {
        this.scanner = new Scanner(System.in);
    }

    public int mostrarMenu() {
        System.out.println("\n-- Menú --");
        System.out.println("1. Agregar Cliente");
        System.out.println("2. Actualizar Cliente");
        System.out.println("3. Eliminar Cliente");
        System.out.println("4. Mostrar Clientes");
        System.out.println("5. Agregar Plan");
        System.out.println("6. Actualizar Plan");
        System.out.println("7. Eliminar Plan");
        System.out.println("8. Mostrar Planes");
        System.out.println("9. Salir");
        System.out.print("Ingrese la opción deseada: ");
        return Integer.parseInt(scanner.nextLine());
    }
    
    public int leerOpcion() {
        return Integer.parseInt(scanner.nextLine());
    }
    
    public int solicitarIdCliente() {
        System.out.print("Ingrese el ID del cliente: ");
        return Integer.parseInt(scanner.nextLine());
    }

    public int solicitarIdPlan() {
        System.out.print("Ingrese el ID del plan: ");
        return Integer.parseInt(scanner.nextLine());
    }

    public Cliente solicitarDatosCliente() {
        
        System.out.println("Ingrese los datos del cliente:");
        System.out.print("Nombres: ");
        String nombres = scanner.nextLine();
        System.out.print("Cédula: ");
        String cedula = scanner.nextLine();
        System.out.print("Ciudad: ");
        String ciudad = scanner.nextLine();
        System.out.print("Marca: ");
        String marca = scanner.nextLine();
        System.out.print("Modelo: ");
        String modelo = scanner.nextLine();
        System.out.print("Numero de Celular: ");
        String numeroCelular = scanner.nextLine();
        System.out.print("Pago Mensual: ");
        double pagoMensual = Double.parseDouble(scanner.nextLine());
        System.out.print("Correo Electronico:");
        String correoElectronico = scanner.nextLine();
        System.out.print("Direccion:");
        String direccion = scanner.nextLine();
        
        Cliente cliente = new Cliente();
        cliente.setNombres(nombres);
        cliente.setCedula(cedula);
        cliente.setCiudad(ciudad);
        cliente.setMarca(marca);
        cliente.setModelo(modelo);
        cliente.setNumeroCelular(numeroCelular);
        cliente.setPagoMensual(pagoMensual);
        cliente.setcorreoElectronico(correoElectronico);
        cliente.setdireccion(direccion);

        return cliente;
    }
    
    public int solicitarTipoPlan() {
        System.out.println("Ingrese el tipo de plan:");
        System.out.println("1. PlanPostPagoMinutosMegasEconomico");
        System.out.println("2. PlanPostPagoMinutos");
        System.out.println("3. PlanPostPagoMegas");
        System.out.println("4. PlanPostPagoMinutosMegas");
        System.out.print("Ingrese la opción deseada: ");
        return Integer.parseInt(scanner.nextLine());
    }
    
    public Plan solicitarDatosPlan(String tipoPlan) {
        if (tipoPlan.equals("PlanPostPagoMinutosMegasEconomico")) {
            return solicitarDatosPlanPostPagoMinutosMegasEconomico();
        } else if (tipoPlan.equals("PlanPostPagoMinutos")) {
            return solicitarDatosPlanPostPagoMinutos();
        } else if (tipoPlan.equals("PlanPostPagoMegas")) {
            return solicitarDatosPlanPostPagoMegas();
        } else if (tipoPlan.equals("PlanPostPagoMinutosMegas")) {
         return solicitarDatosPlanPostPagoMinutosMegas();
        } else {
            System.out.println("Tipo de plan inválido.");
        return null;
        }
    }
    public PlanPostPagoMinutosMegasEconomico solicitarDatosPlanPostPagoMinutosMegasEconomico() {
        System.out.println("Ingrese los datos del plan PlanPostPagoMinutosMegasEconomico:");
        System.out.print("Minutos: ");
        int minutos = Integer.parseInt(scanner.nextLine());
        System.out.print("Costo por minuto: ");
        double costoMinutos = Double.parseDouble(scanner.nextLine());
        System.out.print("Megas en gigas: ");
        int megasEnGigas = Integer.parseInt(scanner.nextLine());
        System.out.print("Costo por cada giga: ");
        double costoPorGigas = Double.parseDouble(scanner.nextLine());
        System.out.print("Porcentaje de descuento: ");
        double porcentajeDescuento = Double.parseDouble(scanner.nextLine());

        PlanPostPagoMinutosMegasEconomico plan = new PlanPostPagoMinutosMegasEconomico();
        plan.setMinutos(minutos);
        plan.setCostoMinutos(costoMinutos);
        plan.setMegasEnGigas(megasEnGigas);
        plan.setCostoPorGigas(costoPorGigas);
        plan.setPorcentajeDescuento(porcentajeDescuento);

        return plan;
    }
    public PlanPostPagoMinutos solicitarDatosPlanPostPagoMinutos() {
        System.out.println("Ingrese los datos del plan PlanPostPagoMinutos:");
        System.out.print("Minutos nacionales: ");
        int minutosNacionales = Integer.parseInt(scanner.nextLine());
        System.out.print("Costo por minuto nacional: ");
        double costoMinutoNacional = Double.parseDouble(scanner.nextLine());
        System.out.print("Minutos internacionales: ");
        int minutosInternacionales = Integer.parseInt(scanner.nextLine());
        System.out.print("Costo por minuto internacional: ");
        double costoMinutoInternacional = Double.parseDouble(scanner.nextLine());

        PlanPostPagoMinutos plan = new PlanPostPagoMinutos();
        plan.setMinutosNacionales(minutosNacionales);
        plan.setCostoMinutoNacional(costoMinutoNacional);
        plan.setMinutosInternacionales(minutosInternacionales);
        plan.setCostoMinutoInternacional(costoMinutoInternacional);

        return plan;
    }
    public PlanPostPagoMegas solicitarDatosPlanPostPagoMegas() {
        System.out.println("Ingrese los datos del plan PlanPostPagoMegas:");
        System.out.print("Megas en gigas: ");
        int megasEnGigas = Integer.parseInt(scanner.nextLine());
        System.out.print("Costo por cada giga: ");
        double costoPorGigas = Double.parseDouble(scanner.nextLine());
        System.out.print("Tarifa base: ");
        double tarifaBase = Double.parseDouble(scanner.nextLine());

        PlanPostPagoMegas plan = new PlanPostPagoMegas();
        plan.setMegasEnGigas(megasEnGigas);
        plan.setCostoPorGigas(costoPorGigas);
        plan.setTarifaBase(tarifaBase);

        return plan;
    }
    public PlanPostPagoMinutosMegas solicitarDatosPlanPostPagoMinutosMegas() {
        System.out.println("Ingrese los datos del plan PlanPostPagoMinutosMegas:");
        System.out.print("Minutos: ");
        int minutos = Integer.parseInt(scanner.nextLine());
        System.out.print("Costo por minuto: ");
        double costoMinutos = Double.parseDouble(scanner.nextLine());
        System.out.print("Megas en gigas: ");
        int megasEnGigas = Integer.parseInt(scanner.nextLine());
        System.out.print("Costo por cada giga: ");
        double costoPorGigas = Double.parseDouble(scanner.nextLine());

        PlanPostPagoMinutosMegas plan = new PlanPostPagoMinutosMegas();
        plan.setMinutos(minutos);
        plan.setCostoMinutos(costoMinutos);
        plan.setMegasGigas(megasEnGigas);
        plan.setCostoPorGigas(costoPorGigas);

        return plan;
    }
    public void mostrarDatosCliente(Cliente cliente) {
        System.out.println("Datos del cliente:");
        System.out.println("ID: " + cliente.getId());
        System.out.println("Nombres: " + cliente.getNombres());
        System.out.println("Cédula: " + cliente.getCedula());
        System.out.println("Ciudad: " + cliente.getCiudad());
        System.out.println("Marca: " + cliente.getMarca());
        System.out.println("Modelo: " + cliente.getModelo());
        System.out.println("Número de Celular: " + cliente.getNumeroCelular());
        System.out.println("Pago Mensual: " + cliente.getPagoMensual());
        System.out.println("Correo Electrónico: " + cliente.getcorreoElectronico());
        System.out.println("Dirección: " + cliente.getdireccion());
        System.out.println("----------------------");
    }
    public void mostrarDatosPlan(Plan plan) {
    System.out.println("Datos del plan:");
    System.out.println("ID: " + plan.getId());
    System.out.println("Tipo de plan: " + plan.getTipoPlan());

    // Utilizamos instanceof para determinar el tipo específico del plan
    if (plan instanceof PlanPostPagoMinutosMegasEconomico) {
        PlanPostPagoMinutosMegasEconomico planEconomico = (PlanPostPagoMinutosMegasEconomico) plan;
        System.out.println("Minutos: " + planEconomico.getMinutos());
        System.out.println("Costo por minuto: " + planEconomico.getCostoMinutos());
        System.out.println("Megas en gigas: " + planEconomico.getMegasEnGigas());
        System.out.println("Costo por cada giga: " + planEconomico.getCostoPorGigas());
        System.out.println("Porcentaje de descuento: " + planEconomico.getPorcentajeDescuento());
    } else if (plan instanceof PlanPostPagoMinutos) {
        PlanPostPagoMinutos planMinutos = (PlanPostPagoMinutos) plan;
        System.out.println("Minutos nacionales: " + planMinutos.getMinutosNacionales());
        System.out.println("Costo por minuto nacional: " + planMinutos.getCostoMinutoNacional());
        System.out.println("Minutos internacionales: " + planMinutos.getMinutosInternacionales());
        System.out.println("Costo por minuto internacional: " + planMinutos.getCostoMinutoInternacional());
        } else if (plan instanceof PlanPostPagoMegas) {
        PlanPostPagoMegas planMegas = (PlanPostPagoMegas) plan;
        System.out.println("Megas en gigas: " + planMegas.getMegasEnGigas());
        System.out.println("Costo por cada giga: " + planMegas.getCostoPorGigas());
        System.out.println("Tarifa base: " + planMegas.getTarifaBase());
    } else if (plan instanceof PlanPostPagoMinutosMegas) {
        PlanPostPagoMinutosMegas planMinutosMegas = (PlanPostPagoMinutosMegas) plan;
        System.out.println("Minutos: " + planMinutosMegas.getMinutos());
        System.out.println("Costo por minuto: " + planMinutosMegas.getCostoMinutos());
        System.out.println("Megas en gigas: " + planMinutosMegas.getMegasGigas());
        System.out.println("Costo por cada giga: " + planMinutosMegas.getCostoPorGigas());
    } else {
        System.out.println("Tipo de plan inválido.");
    }

    System.out.println("----------------------");
    }
    
    public void mostrarClientes(List<Cliente> clientes) {
        if (clientes.isEmpty()) {
            System.out.println("No hay clientes registrados.");
        } else {
            System.out.println("Lista de clientes:");
            for (Cliente cliente : clientes) {
                System.out.println("ID: " + cliente.getId() + ", Nombres: " + cliente.getNombres() + ", Cédula: " + cliente.getCedula());
            }
            System.out.println("----------------------");
        }
    }
    public void mostrarListaPlanes(List<Plan> listaPlanes) {
        System.out.println("----- Lista de Planes -----");
        for (Plan plan : listaPlanes) {
            System.out.println("ID: " + plan.getId());
            System.out.println("Tipo de plan: " + plan.getTipoPlan());

            if (plan instanceof PlanPostPagoMinutosMegasEconomico) {
                PlanPostPagoMinutosMegasEconomico planEconomico = (PlanPostPagoMinutosMegasEconomico) plan;
                System.out.println("Minutos: " + planEconomico.getMinutos());
                System.out.println("Costo por minuto: " + planEconomico.getCostoMinutos());
                System.out.println("Megas en gigas: " + planEconomico.getMegasEnGigas());
                System.out.println("Costo por cada giga: " + planEconomico.getCostoPorGigas());
                System.out.println("Porcentaje de descuento: " + planEconomico.getPorcentajeDescuento());
            } else if (plan instanceof PlanPostPagoMinutos) {
                PlanPostPagoMinutos planMinutos = (PlanPostPagoMinutos) plan;
                System.out.println("Minutos nacionales: " + planMinutos.getMinutosNacionales());
                System.out.println("Costo por minuto nacional: " + planMinutos.getCostoMinutoNacional());
                System.out.println("Minutos internacionales: " + planMinutos.getMinutosInternacionales());
                System.out.println("Costo por minuto internacional: " + planMinutos.getCostoMinutoInternacional());
            } else if (plan instanceof PlanPostPagoMegas) {
                PlanPostPagoMegas planMegas = (PlanPostPagoMegas) plan;
                System.out.println("Megas en gigas: " + planMegas.getMegasEnGigas());
                System.out.println("Costo por cada giga: " + planMegas.getCostoPorGigas());
                System.out.println("Tarifa base: " + planMegas.getTarifaBase());
            } else if (plan instanceof PlanPostPagoMinutosMegas) {
                PlanPostPagoMinutosMegas planMinutosMegas = (PlanPostPagoMinutosMegas) plan;
                System.out.println("Minutos: " + planMinutosMegas.getMinutos());
                System.out.println("Costo por minuto: " + planMinutosMegas.getCostoMinutos());
                System.out.println("Megas en gigas: " + planMinutosMegas.getMegasGigas());
                System.out.println("Costo por cada giga: " + planMinutosMegas.getCostoPorGigas());
            } else {
                System.out.println("Tipo de plan inválido.");
            }

            System.out.println("----------------------");
        }
    }
}


package paquete01;

public abstract class Plan {
    
    private String tipoPlan;
    private int id;

    // Constructor
    public Plan(String tipoPlan) {
        this.tipoPlan = tipoPlan;
    }

    // Getter y setter
    public String getTipoPlan() {
        return tipoPlan;
    }

    public void setTipoPlan(String tipoPlan) {
        this.tipoPlan = tipoPlan;
    }
    
    public int getId() {
        return id;
    }
    
    public void setId(int id) {
        this.id = id;
    }
}

package paquete01;

public class PlanPostPagoMinutosMegas extends Plan{
    
    private int minutos;
    private double costoMinutos;
    private int megasGigas;
    private double costoPorGigas;

    // Constructor
    public PlanPostPagoMinutosMegas() {
        super("PlanPostPagoMinutosMegas");
    }

    public int getMinutos() {
        return minutos;
    }

    public void setMinutos(int minutos) {
        this.minutos = minutos;
    }

    public double getCostoMinutos() {
        return costoMinutos;
    }

    public void setCostoMinutos(double costoMinutos) {
        this.costoMinutos = costoMinutos;
    }

    public int getMegasGigas() {
        return megasGigas;
    }

    public void setMegasGigas(int megasEnGigas) {
        this.megasGigas = megasEnGigas;
    }

    public double getCostoPorGigas() {
        return costoPorGigas;
    }

    public void setCostoPorGigas(double costoPorGigas) {
        this.costoPorGigas = costoPorGigas;
    }
    
}

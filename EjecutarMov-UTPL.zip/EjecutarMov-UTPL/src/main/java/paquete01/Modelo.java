package paquete01;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class Modelo {
    
    private Connection connection;
    private Scanner scanner;
    
    public Modelo() {
        try {
            String url = "jdbc:sqlite:BD/BaseMov-Utpl.db";
            this.connection = DriverManager.getConnection(url);
            this.scanner = new Scanner(System.in);
            System.out.println("Conexion con la base de datos exitosa");
        } catch (SQLException e) {
            System.err.println("Error al conectar con la base de datos: " + e.getMessage());
        }
    }
    public void agregarCliente(Cliente cliente) {
        if (connection != null) {
            String query = "INSERT INTO clientes (nombres, cedula, ciudad, marca, modelo, numeroCelular, pagoMensual, correoElectronico, direccion) " +
                    "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)";
            try (PreparedStatement statement = connection.prepareStatement(query)) {
                statement.setString(1, cliente.getNombres());
                statement.setString(2, cliente.getCedula());
                statement.setString(3, cliente.getCiudad());
                statement.setString(4, cliente.getMarca());
                statement.setString(5, cliente.getModelo());
                statement.setString(6, cliente.getNumeroCelular());
                statement.setDouble(7, cliente.getPagoMensual());
                statement.setString(8, cliente.getcorreoElectronico());
                statement.setString(9, cliente.getdireccion());

                statement.executeUpdate();
                System.out.println("Cliente agregado correctamente.");
            } catch (SQLException e) {
                System.err.println("Error al agregar el cliente: " + e.getMessage());
            }
        }else{
            System.err.println("Error: La conexión a la base de datos no se ha establecido correctamente.");
        }
    }
    public Cliente obtenerClientePorId(int clienteId) {
        String query = "SELECT * FROM clientes WHERE id = ?";
        try (PreparedStatement statement = connection.prepareStatement(query)) {
            statement.setInt(1, clienteId);
            ResultSet resultSet = statement.executeQuery();

            if (resultSet.next()) {
                Cliente cliente = new Cliente();
                cliente.setId(resultSet.getInt("id"));
                cliente.setNombres(resultSet.getString("nombres"));
                cliente.setCedula(resultSet.getString("cedula"));
                cliente.setCiudad(resultSet.getString("ciudad"));
                cliente.setMarca(resultSet.getString("marca"));
                cliente.setModelo(resultSet.getString("modelo"));
                cliente.setNumeroCelular(resultSet.getString("numeroCelular"));
                cliente.setPagoMensual(resultSet.getDouble("pagoMensual"));
                cliente.setcorreoElectronico(resultSet.getString("correoElectronico"));
                cliente.setdireccion(resultSet.getString("direccion"));

                return cliente;
            }
            } catch (SQLException e) {
            System.err.println("Error al obtener el cliente: " + e.getMessage());
        }
        return null;
    }
    public List<Cliente> obtenerTodosLosClientes() {
        List<Cliente> clientes = new ArrayList<>();
        String query = "SELECT * FROM clientes";
        try (PreparedStatement statement = connection.prepareStatement(query)) {
            ResultSet resultSet = statement.executeQuery();

            while (resultSet.next()) {
                Cliente cliente = new Cliente();
                cliente.setId(resultSet.getInt("id"));
                cliente.setNombres(resultSet.getString("nombres"));
                cliente.setCedula(resultSet.getString("cedula"));
                cliente.setCiudad(resultSet.getString("ciudad"));
                cliente.setMarca(resultSet.getString("marca"));
                cliente.setModelo(resultSet.getString("modelo"));
                cliente.setNumeroCelular(resultSet.getString("numeroCelular"));
                cliente.setPagoMensual(resultSet.getDouble("pagoMensual"));
                cliente.setcorreoElectronico(resultSet.getString("correoElectronico"));
                cliente.setdireccion(resultSet.getString("direccion"));

                clientes.add(cliente);
            }
        } catch (SQLException e) {
            System.err.println("Error al obtener los clientes: " + e.getMessage());
        }
        return clientes;
    }
    public void actualizarCliente(Cliente cliente) {
        if (connection != null) {
            String query = "UPDATE clientes SET nombres=?, cedula=?, ciudad=?, marca=?, modelo=?, numeroCelular=?, pagoMensual=?, correoElectronico=?, direccion=? WHERE id=?";
            try (PreparedStatement statement = connection.prepareStatement(query)) {
                statement.setString(1, cliente.getNombres());
                statement.setString(2, cliente.getCedula());
                statement.setString(3, cliente.getCiudad());
                statement.setString(4, cliente.getMarca());
                statement.setString(5, cliente.getModelo());
                statement.setString(6, cliente.getNumeroCelular());
                statement.setDouble(7, cliente.getPagoMensual());
                statement.setString(8, cliente.getcorreoElectronico());
                statement.setString(9, cliente.getdireccion());
                statement.setInt(10, cliente.getId());

                statement.executeUpdate();
                System.out.println("Cliente actualizado correctamente.");
            } catch (SQLException e) {
                System.err.println("Error al actualizar el cliente: " + e.getMessage());
            }
        }else{
            System.err.println("Error: La conexión a la base de datos no se ha establecido correctamente.");
        }
    }
    public void eliminarCliente(int clienteId) {
        if (connection != null) {
            String query = "DELETE FROM clientes WHERE id = ?";
            try (PreparedStatement statement = connection.prepareStatement(query)) {
                statement.setInt(1, clienteId);
                statement.executeUpdate();
                System.out.println("Cliente eliminado correctamente.");
            } catch (SQLException e) {
                System.err.println("Error al eliminar el cliente: " + e.getMessage());
            }
        }else{
            System.err.println("Error: La conexión a la base de datos no se ha establecido correctamente.");
        }
    }
    public void agregarPlanPostPagoMinutosMegasEconomico(PlanPostPagoMinutosMegasEconomico plan) {
        if (connection != null) {
            String query = "INSERT INTO planes (tipoPlan, minutos, costoMinutos, megasEnGigas, costoPorGigas, porcentajeDescuento) " +
                    "VALUES (?, ?, ?, ?, ?, ?)";
            try (PreparedStatement statement = connection.prepareStatement(query)) {
                statement.setString(1, plan.getTipoPlan());
                statement.setInt(2, plan.getMinutos());
                statement.setDouble(3, plan.getCostoMinutos());
                statement.setInt(4, plan.getMegasEnGigas());
                statement.setDouble(5, plan.getCostoPorGigas());
                statement.setDouble(6, plan.getPorcentajeDescuento());

                statement.executeUpdate();
                System.out.println("Plan agregado correctamente.");
            } catch (SQLException e) {
                System.err.println("Error al agregar el plan: " + e.getMessage());
            }
        }else{
            System.err.println("Error: La conexión a la base de datos no se ha establecido correctamente.");
        }
    }
    public void agregarPlanPostPagoMinutos(PlanPostPagoMinutos plan) {
        if (connection != null) {
            String query = "INSERT INTO planes (tipoPlan, minutosNacionales, costoMinutoNacional, minutosInternacionales, costoMinutoInternacional) " +
                    "VALUES (?, ?, ?, ?, ?)";
            try (PreparedStatement statement = connection.prepareStatement(query)) {
                statement.setString(1, plan.getTipoPlan());
                statement.setInt(2, plan.getMinutosNacionales());
                statement.setDouble(3, plan.getCostoMinutoNacional());
                statement.setInt(4, plan.getMinutosInternacionales());
                statement.setDouble(5, plan.getCostoMinutoInternacional());

                statement.executeUpdate();
                System.out.println("Plan agregado correctamente.");
            } catch (SQLException e) {
                System.err.println("Error al agregar el plan: " + e.getMessage());
            }
        }else{
            System.err.println("Error: La conexión a la base de datos no se ha establecido correctamente.");
        }
    }
    
    public void agregarPlan(Plan plan) {
        if (connection != null) {
            String query = "INSERT INTO planes (tipoPlan) VALUES (?)";
            try (PreparedStatement statement = connection.prepareStatement(query)) {
                statement.setString(1, plan.getTipoPlan()); // Aquí se usa setString para tipoPlan
                statement.executeUpdate();
                System.out.println("Plan agregado correctamente.");
            } catch (SQLException e) {
                System.err.println("Error al agregar el plan: " + e.getMessage());
            }
        }else{
            System.err.println("Error: La conexión a la base de datos no se ha establecido correctamente.");
        }
    }
    
    public void agregarPlanPostPagoMegas(PlanPostPagoMegas plan) {
        if (connection != null) {
            String query = "INSERT INTO planes (tipoPlan, megasEnGigas, costoPorGigas, tarifaBase) " +
                    "VALUES (?, ?, ?, ?)";
            try (PreparedStatement statement = connection.prepareStatement(query)) {
                statement.setString(1, plan.getTipoPlan());
                statement.setInt(2, plan.getMegasEnGigas());
                statement.setDouble(3, plan.getCostoPorGigas());
                statement.setDouble(4, plan.getTarifaBase());

                statement.executeUpdate();
                System.out.println("Plan agregado correctamente.");
            } catch (SQLException e) {
                System.err.println("Error al agregar el plan: " + e.getMessage());
            }
        }else{
            System.err.println("Error: La conexión a la base de datos no se ha establecido correctamente.");
        }
    }
    public void agregarPlanPostPagoMinutosMegas(PlanPostPagoMinutosMegas plan) {
        if (connection != null) {
            String query = "INSERT INTO planes (tipoPlan, minutos, costoMinutos, megasEnGigas, costoPorGigas) " +
                    "VALUES (?, ?, ?, ?, ?)";
            try (PreparedStatement statement = connection.prepareStatement(query)) {
                statement.setString(1, plan.getTipoPlan());
                statement.setInt(2, plan.getMinutos());
                statement.setDouble(3, plan.getCostoMinutos());
                statement.setInt(4, plan.getMegasGigas());
                statement.setDouble(5, plan.getCostoPorGigas());

                statement.executeUpdate();
                System.out.println("Plan agregado correctamente.");
            } catch (SQLException e) {
                System.err.println("Error al agregar el plan: " + e.getMessage());
            }
        }else{
            System.err.println("Error: La conexión a la base de datos no se ha establecido correctamente.");
        }
    }
    public Plan obtenerPlanPorId(int planId) {
        String query = "SELECT * FROM planes WHERE id = ?";
        try (PreparedStatement statement = connection.prepareStatement(query)) {
            statement.setInt(1, planId);
            ResultSet resultSet = statement.executeQuery();

            if (resultSet.next()) {
                String tipoPlan = resultSet.getString("tipoPlan");
                switch (tipoPlan) {
                    case "PlanPostPagoMinutosMegasEconomico":
                        PlanPostPagoMinutosMegasEconomico planEconomico = new PlanPostPagoMinutosMegasEconomico();
                        planEconomico.setId(resultSet.getInt("id"));
                        planEconomico.setMinutos(resultSet.getInt("minutos"));
                        planEconomico.setCostoMinutos(resultSet.getDouble("costoMinutos"));
                        planEconomico.setMegasEnGigas(resultSet.getInt("megasEnGigas"));
                        planEconomico.setCostoPorGigas(resultSet.getDouble("costoPorGigas"));
                        planEconomico.setPorcentajeDescuento(resultSet.getDouble("porcentajeDescuento"));
                        return planEconomico;
                    case "PlanPostPagoMinutos":
                        PlanPostPagoMinutos planMinutos = new PlanPostPagoMinutos();
                        planMinutos.setId(resultSet.getInt("id"));
                        planMinutos.setMinutosNacionales(resultSet.getInt("minutosNacionales"));
                        planMinutos.setCostoMinutoNacional(resultSet.getDouble("costoMinutoNacional"));
                        planMinutos.setMinutosInternacionales(resultSet.getInt("minutosInternacionales"));
                        planMinutos.setCostoMinutoInternacional(resultSet.getDouble("costoMinutoInternacional"));
                        return planMinutos;
                    case "PlanPostPagoMegas":
                        PlanPostPagoMegas planMegas = new PlanPostPagoMegas();
                        planMegas.setId(resultSet.getInt("id"));
                        planMegas.setMegasEnGigas(resultSet.getInt("megasEnGigas"));
                        planMegas.setCostoPorGigas(resultSet.getDouble("costoPorGigas"));
                        planMegas.setTarifaBase(resultSet.getDouble("tarifaBase"));
                        return planMegas;
                    case "PlanPostPagoMinutosMegas":
                        PlanPostPagoMinutosMegas planMinutosMegas = new PlanPostPagoMinutosMegas();
                        planMinutosMegas.setId(resultSet.getInt("id"));
                        planMinutosMegas.setMinutos(resultSet.getInt("minutos"));
                        planMinutosMegas.setCostoMinutos(resultSet.getDouble("costoMinutos"));
                        planMinutosMegas.setMegasGigas(resultSet.getInt("megasEnGigas"));
                        planMinutosMegas.setCostoPorGigas(resultSet.getDouble("costoPorGigas"));
                        return planMinutosMegas;
                    default:
                        System.err.println("Tipo de plan inválido.");
                        return null;
                }
            }
        } catch (SQLException e) {
            System.err.println("Error al obtener el plan: " + e.getMessage());
        }
        return null;
    }
    public List<Plan> obtenerTodosLosPlanes() {
        List<Plan> planes = new ArrayList<>();
        String query = "SELECT * FROM planes";
        try (PreparedStatement statement = connection.prepareStatement(query)) {
            ResultSet resultSet = statement.executeQuery();

            while (resultSet.next()) {
                String tipoPlan = resultSet.getString("tipoPlan");
                switch (tipoPlan) {
                    case "PlanPostPagoMinutosMegasEconomico":
                        PlanPostPagoMinutosMegasEconomico planEconomico = new PlanPostPagoMinutosMegasEconomico();
                        planEconomico.setId(resultSet.getInt("id"));
                        planEconomico.setMinutos(resultSet.getInt("minutos"));
                        planEconomico.setCostoMinutos(resultSet.getDouble("costoMinutos"));
                        planEconomico.setMegasEnGigas(resultSet.getInt("megasEnGigas"));
                        planEconomico.setCostoPorGigas(resultSet.getDouble("costoPorGigas"));
                        planEconomico.setPorcentajeDescuento(resultSet.getDouble("porcentajeDescuento"));
                        planes.add(planEconomico);
                        break;
                    case "PlanPostPagoMinutos":
                        PlanPostPagoMinutos planMinutos = new PlanPostPagoMinutos();
                        planMinutos.setId(resultSet.getInt("id"));
                        planMinutos.setMinutosNacionales(resultSet.getInt("minutosNacionales"));
                        planMinutos.setCostoMinutoNacional(resultSet.getDouble("costoMinutoNacional"));
                        planMinutos.setMinutosInternacionales(resultSet.getInt("minutosInternacionales"));
                        planMinutos.setCostoMinutoInternacional(resultSet.getDouble("costoMinutoInternacional"));
                        planes.add(planMinutos);
                        break;
                    case "PlanPostPagoMegas":
                        PlanPostPagoMegas planMegas = new PlanPostPagoMegas();
                        planMegas.setId(resultSet.getInt("id"));
                        planMegas.setMegasEnGigas(resultSet.getInt("megasEnGigas"));
                        planMegas.setCostoPorGigas(resultSet.getDouble("costoPorGigas"));
                        planMegas.setTarifaBase(resultSet.getDouble("tarifaBase"));
                        planes.add(planMegas);
                        break;
                    case "PlanPostPagoMinutosMegas":
                        PlanPostPagoMinutosMegas planMinutosMegas = new PlanPostPagoMinutosMegas();
                        planMinutosMegas.setId(resultSet.getInt("id"));
                        planMinutosMegas.setMinutos(resultSet.getInt("minutos"));
                        planMinutosMegas.setCostoMinutos(resultSet.getDouble("costoMinutos"));
                        planMinutosMegas.setMegasGigas(resultSet.getInt("megasEnGigas"));
                        planMinutosMegas.setCostoPorGigas(resultSet.getDouble("costoPorGigas"));
                        planes.add(planMinutosMegas);
                        break;
                    default:
                        System.err.println("Tipo de plan inválido.");
                        break;
                }
            }
        } catch (SQLException e) {
            System.err.println("Error al obtener los planes: " + e.getMessage());
        }
        return planes;
    }
    public void actualizarPlan(Plan plan) {
        if (connection != null) {
            String query = "UPDATE planes SET tipoPlan=?, minutos=?, costoMinutos=?, megasEnGigas=?, costoPorGigas=?, porcentajeDescuento=?, minutosNacionales=?, costoMinutoNacional=?, minutosInternacionales=?, costoMinutoInternacional=?, tarifaBase=? WHERE id=?";
            try (PreparedStatement statement = connection.prepareStatement(query)) {
                statement.setString(1, plan.getTipoPlan());
                switch (plan.getTipoPlan()) {
                    case "PlanPostPagoMinutosMegasEconomico":
                        statement.setInt(2, ((PlanPostPagoMinutosMegasEconomico) plan).getMinutos());
                        statement.setDouble(3, ((PlanPostPagoMinutosMegasEconomico) plan).getCostoMinutos());
                        statement.setInt(4, ((PlanPostPagoMinutosMegasEconomico) plan).getMegasEnGigas());
                        statement.setDouble(5, ((PlanPostPagoMinutosMegasEconomico) plan).getCostoPorGigas());
                        statement.setDouble(6, ((PlanPostPagoMinutosMegasEconomico) plan).getPorcentajeDescuento());
                        break;
                    case "PlanPostPagoMinutos":
                        statement.setInt(7, ((PlanPostPagoMinutos) plan).getMinutosNacionales());
                        statement.setDouble(8, ((PlanPostPagoMinutos) plan).getCostoMinutoNacional());
                        statement.setInt(9, ((PlanPostPagoMinutos) plan).getMinutosInternacionales());
                        statement.setDouble(10, ((PlanPostPagoMinutos) plan).getCostoMinutoInternacional());
                        break;
                    case "PlanPostPagoMegas":
                        statement.setInt(2, ((PlanPostPagoMegas) plan).getMegasEnGigas());
                        statement.setDouble(3, ((PlanPostPagoMegas) plan).getCostoPorGigas());
                        statement.setDouble(11, ((PlanPostPagoMegas) plan).getTarifaBase());
                        break;
                    case "PlanPostPagoMinutosMegas":
                        statement.setInt(2, ((PlanPostPagoMinutosMegas) plan).getMinutos());
                        statement.setDouble(3, ((PlanPostPagoMinutosMegas) plan).getCostoMinutos());
                        statement.setInt(4, ((PlanPostPagoMinutosMegas) plan).getMegasGigas());
                        statement.setDouble(5, ((PlanPostPagoMinutosMegas) plan).getCostoPorGigas());
                        break;
                    default:
                        break;
                }
                statement.setInt(12, plan.getId());

                statement.executeUpdate();
                System.out.println("Plan actualizado correctamente.");
            } catch (SQLException e) {
                System.err.println("Error al actualizar el plan: " + e.getMessage());
            }
            } else {
            System.err.println("Error: La conexión a la base de datos no se ha establecido correctamente.");
        }
    }
    public void eliminarPlan(int planId) {
        if (connection != null) {
            String query = "DELETE FROM planes WHERE id = ?";
            try (PreparedStatement statement = connection.prepareStatement(query)) {
                statement.setInt(1, planId);
                statement.executeUpdate();
                System.out.println("Plan eliminado correctamente.");
            } catch (SQLException e) {
                System.err.println("Error al eliminar el plan: " + e.getMessage());
            }
        } else {
        System.err.println("Error: La conexión a la base de datos no se ha establecido correctamente.");
    }
    }
}

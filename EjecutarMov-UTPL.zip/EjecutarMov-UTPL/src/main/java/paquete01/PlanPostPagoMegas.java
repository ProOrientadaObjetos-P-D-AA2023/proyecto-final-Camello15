package paquete01;

public class PlanPostPagoMegas extends Plan{
    private int megasEnGigas;
    private double costoPorGigas;
    private double tarifaBase;

    // Constructor
    public PlanPostPagoMegas() {
        super("PlanPostPagoMegas");
    }

    public int getMegasEnGigas() {
        return megasEnGigas;
    }

    public void setMegasEnGigas(int megasEnGigas) {
        this.megasEnGigas = megasEnGigas;
    }

    public double getCostoPorGigas() {
        return costoPorGigas;
    }

    public void setCostoPorGigas(double costoPorGigas) {
        this.costoPorGigas = costoPorGigas;
    }

    public double getTarifaBase() {
        return tarifaBase;
    }

    public void setTarifaBase(double tarifaBase) {
        this.tarifaBase = tarifaBase;
    }
}

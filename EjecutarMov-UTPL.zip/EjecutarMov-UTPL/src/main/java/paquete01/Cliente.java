package paquete01;

public class Cliente {
    private int id;
    private String nombres;
    private String cedula;
    private String ciudad;
    private String marca;
    private String modelo;
    private String numeroCelular;
    private double pagoMensual;
    private String correoElectronico;
    private String direccion;

    public Cliente() {
    }
    
    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getNombres() {
        return nombres;
    }

    public void setNombres(String nombres) {
        this.nombres = nombres;
    }

    public String getCedula() {
        return cedula;
    }

    public void setCedula(String cedula) {
        this.cedula = cedula;
    }
    public String getCiudad() {
        return ciudad;
    }

    public void setCiudad(String ciudad) {
        this.ciudad = ciudad;
    }

    public String getMarca() {
        return marca;
    }

    public void setMarca(String marca) {
        this.marca = marca;
    }

    public String getModelo() {
        return modelo;
    }

    public void setModelo(String modelo) {
        this.modelo = modelo;
    }
    public String getNumeroCelular() {
        return numeroCelular;
    }

    public void setNumeroCelular(String numeroCelular) {
        this.numeroCelular = numeroCelular;
    }

    public double getPagoMensual() {
        return pagoMensual;
    }

    public void setPagoMensual(double pagoMensual) {
        this.pagoMensual = pagoMensual;
    }

    public String getcorreoElectronico() {
        return correoElectronico;
    }

    public void setcorreoElectronico(String correoElectronico) {
        this.correoElectronico = correoElectronico;
    }
    public String getdireccion() {
        return direccion;
    }

    public void setdireccion(String direccion) {
        this.direccion = direccion;
    }

    // Método toString para obtener una representación de texto del objeto Cliente
    @Override
    public String toString() {
        return "Cliente [id=" + id + ", nombres=" + nombres + ", cedula=" + cedula + ", ciudad=" + ciudad + ", marca="
                + marca + ", modelo=" + modelo + ", numeroCelular=" + numeroCelular + ", pagoMensual=" + pagoMensual
                + ", correoElectronico=" + correoElectronico + ", direccion=" + direccion + "]";
    }
}
